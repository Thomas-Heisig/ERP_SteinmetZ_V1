// src/components/Dashboard/DashboardHeader.tsx

import React, { memo } from "react";
import { useTranslation } from "react-i18next";
import { HealthStatus } from "../../hooks/useHealth";

interface Props {
  health: { status: HealthStatus; version?: string };
  statusColor: string;
  statusTextKey: string; // i18n-Key
  currentTime: Date;
  onToggleChat: () => void;
}

export const DashboardHeader: React.FC<Props> = memo(
  ({ health, statusColor, statusTextKey, currentTime, onToggleChat }) => {
    const { t } = useTranslation();

    const timeString = currentTime.toLocaleTimeString("de-DE");
    const dateString = currentTime.toLocaleDateString("de-DE");

    return (
      <header className="dashboard-header" aria-label={t("dashboard.title")}>
        <div className="header-left">
          <h1 className="dashboard-title">
            {t("dashboard.title")}
            <span className="subtitle">Funktionskatalog</span>
          </h1>

          {health.version && (
            <div className="version-info" aria-label="Systemversion">
              v{health.version}
            </div>
          )}
        </div>

        <div className="header-right">
          {/* Systemstatus */}
          <div
            className="status-display"
            role="status"
            aria-live="polite"
            aria-atomic="true"
          >
            <span
              className="status-dot"
              style={{ backgroundColor: statusColor }}
              aria-label={t(statusTextKey)}
              title={t(statusTextKey)}
            />
            <span className="status-text">{t(statusTextKey)}</span>
          </div>

          {/* Datum & Uhrzeit */}
          <div className="time-display" aria-label="Aktuelle Uhrzeit">
            <time className="time" dateTime={currentTime.toISOString()}>
              {timeString}
            </time>
            <time className="date" dateTime={currentTime.toISOString()}>
              {dateString}
            </time>
          </div>

          {/* Chat öffnen */}
          <button
            className="open-chat-btn"
            type="button"
            onClick={onToggleChat}
            aria-label={t("dashboard.openChat")}
            title={t("dashboard.openChat")}
          >
            💬
          </button>
        </div>
      </header>
    );
  }
);

DashboardHeader.displayName = "DashboardHeader";
