// src/components/Dashboard/types.ts

// =============================================================================
// CORE TYPES - Grundlegende Typdefinitionen
// =============================================================================

/**
 * Backend Health Status mit erweiterten Zuständen
 */
export type HealthStatus =
  | "healthy"        // Alles funktioniert normal
  | "unhealthy"      // Teilweise Ausfälle
  | "error"          // Kritischer Fehler
  | "checking"       // Status wird überprüft
  | "unknown"        // Status unbekannt
  | "offline"        // Backend nicht erreichbar
  | "degraded";      // Leistung beeinträchtigt

/**
 * Erweiterte Node-Kind-Typen für verschiedene Inhalte
 */
export type NodeKind = 
  | "category"       // Hauptkategorie
  | "group"         // Gruppierung
  | "section"       // Abschnitt
  | "function"      // Funktion
  | "document"      // Dokument
  | "api"           // API Endpoint
  | "report"        // Bericht
  | "dashboard"     // Dashboard
  | "settings"      // Einstellungen
  | "tool";         // Werkzeug

/**
 * Prioritätslevel für Nodes
 */
export type PriorityLevel = 
  | "low"
  | "medium" 
  | "high"
  | "critical";

/**
 * UI Theme Varianten
 */
export type ThemeVariant = 
  | "light"
  | "dark" 
  | "lcars"
  | "auto";

/**
 * Sprachunterstützung
 */
export type LanguageCode = 
  | "de"    // Deutsch
  | "en"    // Englisch
  | "fr"    // Französisch
  | "es";   // Spanisch

// =============================================================================
// METADATA TYPES - Metadaten-Strukturen
// =============================================================================

/**
 * Basis-Metadaten-Schnittstelle
 */
export interface BaseNodeMeta {
  area?: string;
  category?: string;
  business_area?: string;
  confidence?: number;
  version?: string;
  author?: string;
  last_modified_by?: string;
}

/**
 * Sicherheitsbezogene Metadaten
 */
export interface SecurityMeta {
  pii_class?: "public" | "internal" | "confidential" | "restricted";
  compliance?: string[];
  access_level?: "public" | "user" | "admin" | "system";
  encryption_required?: boolean;
  audit_required?: boolean;
}

/**
 Performance-Metadaten
 */
export interface PerformanceMeta {
  response_time?: number;
  throughput?: number;
  availability?: number;
  cache_ttl?: number;
  max_concurrent?: number;
}

/**
 * Business-Metadaten
 */
export interface BusinessMeta {
  cost_center?: string;
  profit_center?: string;
  business_unit?: string;
  revenue_impact?: "low" | "medium" | "high";
  criticality?: PriorityLevel;
  sla_required?: boolean;
}

/**
 * Erweiterte Metadaten-Schnittstelle
 */
export interface NodeMeta extends BaseNodeMeta, SecurityMeta, PerformanceMeta, BusinessMeta {
  // Zusätzliche dynamische Felder
  [key: string]: unknown;
}

// =============================================================================
// NODE TYPES - Haupt-Node-Strukturen
// =============================================================================

/**
 * Basis-Node-Schnittstelle mit gemeinsamen Eigenschaften
 */
export interface BaseNode {
  id: string;
  title: string;
  description?: string;
  icon?: string;
  kind: NodeKind;
  parent_id?: string | null;
}

/**
 * Erweiterte Node-Schnittstelle für das Dashboard
 */
export interface NodeDetail extends BaseNode {
  // Hierarchie und Struktur
  children?: NodeDetail[];
  breadcrumbs?: BreadcrumbItem[];
  path?: string;
  
  // Metadaten und Regeln
  meta?: NodeMeta;
  rules?: RuleEntry[];
  
  // Technische Eigenschaften
  source?: string;
  weight?: number;
  priority?: PriorityLevel;
  
  // Zeitstempel
  createdAt?: string;
  updatedAt?: string;
  last_accessed?: string;
  
  // Datei- und Download-Informationen
  size?: number;
  downloadUrl?: string;
  mime_type?: string;
  file_extension?: string;
  
  // Tags und Kategorisierung
  tags?: string[];
  categories?: string[];
  
  // UI und Layout
  widget?: string;
  layout?: string;
  actions?: string[];
  refresh_interval?: number;
  data_source?: string;
  
  // Status und Verfügbarkeit
  status?: "active" | "inactive" | "deprecated" | "maintenance";
  available?: boolean;
  
  // Statistiken und Nutzung
  usage_count?: number;
  last_used?: string;
  popularity?: number;
}

/**
 * Breadcrumb-Element für Navigation
 */
export interface BreadcrumbItem {
  id: string;
  title: string;
  icon?: string;
  kind?: NodeKind;
}

/**
 * Regel-Einträge für Business Logic
 */
export interface RuleEntry {
  id: string;
  name?: string;
  description?: string;
  type?: "validation" | "transformation" | "business";
  severity?: "info" | "warning" | "error";
  conditions?: RuleCondition[];
  actions?: RuleAction[];
  [key: string]: unknown;
}

/**
 * Regel-Bedingung
 */
export interface RuleCondition {
  field: string;
  operator: "equals" | "contains" | "greater_than" | "less_than";
  value: unknown;
}

/**
 * Regel-Aktion
 */
export interface RuleAction {
  type: "notify" | "transform" | "block" | "log";
  target: string;
  parameters?: Record<string, unknown>;
}

// =============================================================================
// SEARCH & FILTER TYPES - Such- und Filter-Funktionalität
// =============================================================================

/**
 * Suchfilter-Optionen
 */
export type SearchFilter = 
  | "category" 
  | "function" 
  | "document" 
  | "all";

/**
 * Suchparameter für erweiterte Suche
 */
export interface SearchParams {
  query: string;
  filters: NodeKind[];
  limit?: number;
  offset?: number;
  sort_by?: "relevance" | "title" | "created" | "updated";
  sort_order?: "asc" | "desc";
}

/**
 * Suchergebnis mit erweiterten Eigenschaften
 */
export interface SearchResult extends BaseNode {
  // Suchrelevanz
  relevance?: number;
  highlight?: {
    title?: string[];
    description?: string[];
  };
  
  // Zusätzliche Such-Metadaten
  match_type?: "exact" | "partial" | "fuzzy";
  score?: number;
}

/**
 * Such-Response mit Pagination
 */
export interface SearchResponse {
  results: SearchResult[];
  total: number;
  page: number;
  page_size: number;
  has_more: boolean;
  query_time: number;
}

// =============================================================================
// STATE MANAGEMENT TYPES - State Management Typen
// =============================================================================

/**
 * Konfiguration für den Functions Catalog
 */
export interface FunctionsCatalogConfig {
  baseUrl: string;
  timeout?: number;
  retryAttempts?: number;
  cacheEnabled?: boolean;
  cacheTTL?: number;
}

/**
 * Vollständiger State des Functions Catalog
 */
export interface FunctionsCatalogState {
  // Basis-Daten
  roots: NodeDetail[];
  rootsLoading: boolean;
  rootsError: unknown;
  
  // Navigation und Selektion
  selectedId: string;
  selectNode: (id: string) => void;
  
  // Aktueller Node
  node: NodeDetail | null;
  nodeLoading: boolean;
  nodeError: unknown;
  
  // Suchfunktionalität
  searchQuery: string;
  searchResults: SearchResult[];
  search: (query: string, filter: NodeKind[]) => void;
  searchLoading: boolean;
  searchParams: SearchParams;
  
  // Aktions-Funktionen
  reloadIndex: () => void;
  refreshNode: (id: string) => void;
  clearSelection: () => void;
  
  // Regeln und Validierung
  rules: RuleEntry[];
  validateNode?: (node: NodeDetail) => ValidationResult[];
  
  // Cache und Performance
  cache: Map<string, NodeDetail>;
  lastUpdated: number;
}

/**
 * Validierungsergebnis
 */
export interface ValidationResult {
  ruleId: string;
  severity: "info" | "warning" | "error";
  message: string;
  field?: string;
  passed: boolean;
}

// =============================================================================
// NAVIGATION TYPES - Navigations-Typen
// =============================================================================

/**
 * Navigations-Stack für Breadcrumb-Navigation
 */
export type NavigationStack = NodeDetail[];

/**
 * Navigations-Aktion
 */
export interface NavigationAction {
  type: "push" | "pop" | "replace" | "clear";
  node?: NodeDetail;
  index?: number;
}

/**
 * Navigations-State
 */
export interface NavigationState {
  stack: NavigationStack;
  currentIndex: number;
  canGoBack: boolean;
  canGoForward: boolean;
}

// =============================================================================
// UI & COMPONENT TYPES - UI-Komponenten Typen
// =============================================================================

/**
 * Dashboard Header Props
 */
export interface DashboardHeaderProps {
  health: HealthInfo;
  statusColor: string;
  statusTextKey: string;
  currentTime: Date;
  onToggleChat: () => void;
  onNavigateHome: () => void;
  showHomeButton: boolean;
  className?: string;
}

/**
 * Health Information
 */
export interface HealthInfo {
  status: HealthStatus;
  version?: string;
  lastCheck?: Date;
  responseTime?: number;
  details?: HealthDetails;
}

/**
 * Detaillierte Health-Informationen
 */
export interface HealthDetails {
  database: HealthStatus;
  api: HealthStatus;
  cache: HealthStatus;
  storage: HealthStatus;
  message?: string;
}

/**
 * Dashboard TopBar Props
 */
export interface DashboardTopBarProps {
  roots: NodeDetail[];
  selectedId: string;
  onSelectCategory: (id: string) => void;
  searchFilter: SearchFilter;
  setSearchFilter: (filter: SearchFilter) => void;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSearchClear: () => void;
  searchLoading: boolean;
  searchQuery: string;
  searchInputRef?: React.RefObject<HTMLInputElement>;
  isSearchActive: boolean;
  className?: string;
}

/**
 * Category Grid Props
 */
export interface CategoryGridProps {
  roots: NodeDetail[];
  onCategoryClick: (node: NodeDetail) => void;
  getDefaultIcon: (node: NodeDetail) => string;
  loading?: boolean;
  error?: unknown;
  className?: string;
}

/**
 * Node Details Props
 */
export interface NodeDetailsProps {
  node: NodeDetail;
  loading: boolean;
  error: unknown;
  onBack: () => void;
  navigationStack: NavigationStack;
  onSelectNode: (id: string) => void;
  setNavigationStack: React.Dispatch<React.SetStateAction<NavigationStack>>;
  onRootNavigation?: () => void;
  className?: string;
}

/**
 * Search Overlay Props
 */
export interface SearchOverlayProps {
  results: SearchResult[];
  onSelect: (id: string) => void;
  onClose: () => void;
  searchQuery: string;
  searchFilter: SearchFilter;
  className?: string;
}

/**
 * Loading Screen Props
 */
export interface LoadingScreenProps {
  message?: string;
  showSpinner?: boolean;
  progress?: number;
  className?: string;
}

/**
 * Error Screen Props
 */
export interface ErrorScreenProps {
  error: unknown;
  onRetry: () => void;
  title?: string;
  message?: string;
  showDetails?: boolean;
  className?: string;
}

// =============================================================================
// THEME & SETTINGS TYPES - Theme und Einstellungen
// =============================================================================

/**
 * Theme Konfiguration
 */
export interface ThemeConfig {
  variant: ThemeVariant;
  colors: ThemeColors;
  typography: TypographyConfig;
  spacing: SpacingConfig;
  breakpoints: Breakpoints;
}

/**
 * Theme Farben
 */
export interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  error: string;
  warning: string;
  success: string;
  info: string;
  text: {
    primary: string;
    secondary: string;
    disabled: string;
  };
}

/**
 * Typographie Konfiguration
 */
export interface TypographyConfig {
  fontFamily: string;
  fontSize: {
    xs: string;
    sm: string;
    base: string;
    lg: string;
    xl: string;
    "2xl": string;
    "3xl": string;
  };
  fontWeight: {
    light: number;
    normal: number;
    medium: number;
    semibold: number;
    bold: number;
  };
}

/**
 * Abstände Konfiguration
 */
export interface SpacingConfig {
  xs: string;
  sm: string;
  md: string;
  lg: string;
  xl: string;
  "2xl": string;
}

/**
 * Breakpoints für responsive Design
 */
export interface Breakpoints {
  sm: string;
  md: string;
  lg: string;
  xl: string;
  "2xl": string;
}

// =============================================================================
// QUICK CHAT TYPES - Quick Chat Integration
// =============================================================================

/**
 * Quick Chat Controller
 */
export interface QuickChatController {
  isOpen: boolean;
  onClose: () => void;
  position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
  size?: "sm" | "md" | "lg" | "xl";
  minimized?: boolean;
}

/**
 * Chat Message
 */
export interface ChatMessage {
  id: string;
  content: string;
  role: "user" | "assistant" | "system";
  timestamp: Date;
  type?: "text" | "code" | "error" | "warning";
  metadata?: Record<string, unknown>;
}

/**
 * Chat Session
 */
export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
  model?: string;
}

// =============================================================================
// UTILITY TYPES - Hilfs-Typen
// =============================================================================

/**
 * API Response Wrapper
 */
export interface ApiResponse<T = unknown> {
  data: T;
  success: boolean;
  message?: string;
  timestamp: Date;
  version: string;
}

/**
 * Paginated API Response
 */
export interface PaginatedApiResponse<T = unknown> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    page_size: number;
    total: number;
    total_pages: number;
    has_next: boolean;
    has_prev: boolean;
  };
}

/**
 * Error Response
 */
export interface ErrorResponse {
  error: string;
  code: string;
  details?: unknown;
  timestamp: Date;
}

/**
 * Loading State
 */
export interface LoadingState {
  isLoading: boolean;
  isSuccess: boolean;
  isError: boolean;
  error: unknown;
  progress?: number;
}

// =============================================================================
// EVENT TYPES - Event-Typen
// =============================================================================

/**
 * Dashboard Events
 */
export interface DashboardEvents {
  onNodeSelect: (node: NodeDetail) => void;
  onSearch: (query: string, results: SearchResult[]) => void;
  onError: (error: unknown, context: string) => void;
  onThemeChange: (theme: ThemeVariant) => void;
  onLanguageChange: (language: LanguageCode) => void;
}

// =============================================================================
// EXPORT ALL TYPES - Alle Typen exportieren
// =============================================================================

export type {
  // Alias für Rückwärtskompatibilität
  NodeDetail as CategoryNode,
  SearchResult as SearchResultItem,
  FunctionsCatalogState as CatalogState,
};

/**
 * Utility Type zur Erstellung von partiellen Typen mit required Feldern
 */
export type PartialWithRequired<T, K extends keyof T> = Partial<T> & Pick<T, K>;

/**
 * Utility Type für nullable Optionen
 */
export type Nullable<T> = T | null | undefined;

/**
 * Utility Type für rekursive partielle Typen
 */
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};