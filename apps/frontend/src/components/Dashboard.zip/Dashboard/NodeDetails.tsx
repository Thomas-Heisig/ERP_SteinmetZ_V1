// src/components/Dashboard/NodeDetails.tsx

import React, { memo } from "react";
import { useTranslation } from "react-i18next";

// WICHTIG: Der ECHTE Typ muss aus dem Hook kommen!
import { NodeDetail } from "../../hooks/useFunctionsCatalog";

interface NodeDetailsProps {
  node: NodeDetail;
  loading: boolean;
  error: unknown;
  onBack: () => void;
  navigationStack: NodeDetail[];
  onSelectNode: (id: string) => void;
  setNavigationStack: React.Dispatch<React.SetStateAction<NodeDetail[]>>;
}

export const NodeDetails: React.FC<NodeDetailsProps> = memo(
  ({
    node,
    loading,
    error,
    onBack,
    navigationStack,
    onSelectNode,
    setNavigationStack,
  }) => {
    const { t } = useTranslation();

    // --------------------------------------------------------------------
    // Breadcrumb Navigation
    // --------------------------------------------------------------------
    const handleBreadcrumbClick = (index: number) => {
      if (index < navigationStack.length) {
        setNavigationStack(navigationStack.slice(0, index + 1));
      }
    };

    // --------------------------------------------------------------------
    // Loading State
    // --------------------------------------------------------------------
    if (loading) {
      return (
        <div className="node-details-loading" role="status" aria-live="polite">
          <div className="loading-spinner large"></div>
          <div className="loading-content">
            <h2 className="loading-title">{t("dashboard.loading.title")}</h2>
            <p className="loading-message">{t("dashboard.loading.message")}</p>
          </div>
        </div>
      );
    }

    // --------------------------------------------------------------------
    // Error State
    // --------------------------------------------------------------------
    if (error) {
      return (
        <div className="node-details-error" role="alert">
          <div className="error-icon">⚠️</div>
          <div className="error-content">
            <h3 className="error-title">{t("dashboard.error.title")}</h3>
            <p className="error-message">{t("dashboard.error.message")}</p>

            <details className="error-details">
              <summary>{t("dashboard.error.details")}</summary>
              <pre className="error-stack">{String(error)}</pre>
            </details>

            <div className="error-actions">
              <button className="btn-primary" onClick={onBack} type="button">
                {t("dashboard.back")}
              </button>
              <button
                className="btn-secondary"
                onClick={() => window.location.reload()}
                type="button"
              >
                {t("dashboard.retry")}
              </button>
            </div>
          </div>
        </div>
      );
    }

    // --------------------------------------------------------------------
    // Helper
    // --------------------------------------------------------------------
    const formatFileSize = (bytes: number): string => {
      if (bytes === 0) return "0 B";
      const k = 1024;
      const sizes = ["B", "KB", "MB", "GB"];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`;
    };

    const formatDate = (dateString: string): string =>
      new Date(dateString).toLocaleDateString(undefined, {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });

    // --------------------------------------------------------------------
    // Rendering
    // --------------------------------------------------------------------
    return (
      <div className="node-details" aria-labelledby="node-title">
        {/* Breadcrumb */}
        <nav className="breadcrumb-nav" aria-label="Breadcrumb">
          <button
            className="back-btn"
            onClick={onBack}
            type="button"
            aria-label={t("dashboard.back")}
          >
            <span className="back-icon">←</span>
            <span className="back-text">{t("dashboard.back")}</span>
          </button>

          <div className="breadcrumb-path">
            {navigationStack.map((navNode, index) => (
              <React.Fragment key={navNode.id}>
                <button
                  className="breadcrumb-item"
                  onClick={() => handleBreadcrumbClick(index)}
                  type="button"
                >
                  {navNode.icon && (
                    <span className="breadcrumb-icon">{navNode.icon}</span>
                  )}
                  {navNode.title}
                </button>
                <span className="breadcrumb-separator">/</span>
              </React.Fragment>
            ))}

            <span className="breadcrumb-current">
              {node.icon && <span className="breadcrumb-icon">{node.icon}</span>}
              {node.title}
            </span>
          </div>
        </nav>

        {/* Node Header */}
        <section className="node-header">
          <div className="node-title-section">
            {node.icon && <div className="node-icon-large">{node.icon}</div>}

            <div className="node-title-content">
              <h1 className="node-title" id="node-title">
                {node.title}
              </h1>

              {/* Meta Badges (nur Felder, die im echten Typ existieren!) */}
              <div className="node-meta-badges">
                {node.kind && (
                  <span className="node-kind-badge">{node.kind}</span>
                )}

                {node.source && (
                  <span className="node-area-badge">{node.source}</span>
                )}

                {node.weight !== undefined && (
                  <span className="node-priority-badge">{node.weight}</span>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Content */}
        <div className="node-content">
          {/* Description */}
          {node.description && (
            <section className="node-section">
              <h2 className="section-title">{t("dashboard.description")}</h2>
              <div className="node-description">{node.description}</div>
            </section>
          )}

          {/* Metadata */}
          {(node.meta || node.createdAt || node.updatedAt) && (
            <section className="node-section">
              <h2 className="section-title">{t("dashboard.metadata")}</h2>

              <div className="node-metadata-grid">
                {node.createdAt && (
                  <div className="metadata-item">
                    <span className="metadata-label">
                      {t("dashboard.created")}:
                    </span>
                    <span className="metadata-value">
                      {formatDate(node.createdAt)}
                    </span>
                  </div>
                )}

                {node.updatedAt && (
                  <div className="metadata-item">
                    <span className="metadata-label">
                      {t("dashboard.updated")}:
                    </span>
                    <span className="metadata-value">
                      {formatDate(node.updatedAt)}
                    </span>
                  </div>
                )}

                {node.meta &&
                  Object.entries(node.meta).map(([key, value]) => (
                    <div key={key} className="metadata-item">
                      <span className="metadata-label">{key}:</span>
                      <span className="metadata-value">{String(value)}</span>
                    </div>
                  ))}
              </div>
            </section>
          )}

          {/* Children */}
          {Array.isArray(node.children) && node.children.length > 0 && (
            <section className="node-section">
              <h2 className="section-title">
                {t("dashboard.children")} ({node.children.length})
              </h2>

              <div className="children-grid">
                {node.children.map((child) => (
                  <button
                    key={child.id}
                    className="child-card"
                    onClick={() => onSelectNode(child.id)}
                    type="button"
                  >
                    <div className="child-header">
                      <span className="child-icon">{child.icon || "📄"}</span>
                      <span className="child-title">{child.title}</span>
                    </div>

                    {child.description && (
                      <p className="child-description">{child.description}</p>
                    )}

                    <div className="child-meta">
                      {child.kind && (
                        <span className="child-kind">{child.kind}</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Empty State */}
          {Array.isArray(node.children) && node.children.length === 0 && (
            <section className="node-section empty-section">
              <div className="empty-state">
                <div className="empty-icon">📁</div>
                <h3 className="empty-title">
                  {t("dashboard.empty.children.title")}
                </h3>
                <p className="empty-message">
                  {t("dashboard.empty.children.message")}
                </p>
              </div>
            </section>
          )}
        </div>

        {/* Actions */}
        <div className="node-actions">
          <button className="btn-secondary" onClick={onBack} type="button">
            {t("dashboard.back")}
          </button>
        </div>
      </div>
    );
  }
);

NodeDetails.displayName = "NodeDetails";

export default NodeDetails;
