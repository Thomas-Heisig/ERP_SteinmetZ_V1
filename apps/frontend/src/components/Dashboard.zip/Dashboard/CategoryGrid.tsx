// src/components/QuickChat/components/Dashboard/CategoryGrid.tsx

import React, { memo } from "react";
import { NodeDetail } from "./types";

export interface CategoryGridProps {
  roots: NodeDetail[];
  onCategoryClick: (node: NodeDetail) => void;
  getDefaultIcon: (node: NodeDetail) => string;
}

export const CategoryGrid: React.FC<CategoryGridProps> = memo(
  ({ roots, onCategoryClick, getDefaultIcon }) => {
    // Defensive Copy & alphabetische Sortierung
    const sorted = [...roots].sort((a, b) =>
      a.title.localeCompare(b.title, "de-DE"),
    );

    // Leerer Zustand (falls Backend keine Kategorien liefert)
    if (sorted.length === 0) {
      return (
        <section
          className="category-grid empty"
          aria-label="Keine Kategorien gefunden"
        >
          <p className="empty-message">Keine Kategorien vorhanden.</p>
        </section>
      );
    }

    return (
      <section
        className="category-grid"
        aria-label="Kategorienübersicht"
        role="navigation"
      >
        {sorted.map((cat) => {
          const icon = cat.icon || getDefaultIcon(cat);

          return (
            <button
              key={cat.id}
              className="category-card"
              onClick={() => onCategoryClick(cat)}
              type="button"
              aria-label={cat.title}
              title={cat.title}
            >
              {/* Icon */}
              <div className="category-icon" aria-hidden="true">
                {icon}
              </div>

              {/* Inhalt */}
              <div className="category-content">
                <h3 className="category-title">{cat.title}</h3>

                {cat.description && (
                  <p className="category-description">
                    {cat.description}
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </section>
    );
  }
);

CategoryGrid.displayName = "CategoryGrid";

export default CategoryGrid;
