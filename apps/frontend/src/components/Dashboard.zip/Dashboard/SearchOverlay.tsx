// src/components/Dashboard/SearchOverlay.tsx
import React, { useEffect, useRef, memo } from "react";
import { useTranslation } from "react-i18next";
import { NodeDetail } from "./types";

interface SearchOverlayProps {
  results: NodeDetail[];
  onSelect: (id: string) => void;
  onClose: () => void;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = memo(
  ({ results, onSelect, onClose }) => {
    const { t } = useTranslation();
    const containerRef = useRef<HTMLDivElement>(null);

    // ───────────────────────────────────────────────
    // ESC → Overlay schließen
    // ───────────────────────────────────────────────
    useEffect(() => {
      const escListener = (e: KeyboardEvent) => {
        if (e.key === "Escape") onClose();
      };
      document.addEventListener("keydown", escListener);
      return () => document.removeEventListener("keydown", escListener);
    }, [onClose]);

    // ───────────────────────────────────────────────
    // Autofokus (Fokusfalle für Accessibility)
    // ───────────────────────────────────────────────
    useEffect(() => {
      containerRef.current?.focus();
    }, []);

    return (
      <div
        className="search-overlay"
        role="dialog"
        aria-modal="true"
        aria-label={t("dashboard.search.results")}
        tabIndex={-1}
        ref={containerRef}
      >
        {/* ▶ Header */}
        <div className="search-overlay-header">
          <h3 className="search-title">{t("dashboard.search.results")}</h3>

          <button
            className="close-btn"
            onClick={onClose}
            type="button"
            aria-label={t("dashboard.search.close")}
            title={t("dashboard.search.close")}
          >
            ×
          </button>
        </div>

        {/* ▶ Body */}
        <div className="search-results">
          {/* Keine Treffer */}
          {results.length === 0 && (
            <div className="no-results" role="note">
              {t("dashboard.search.noResults")}
            </div>
          )}

          {/* Trefferliste */}
          {results.map((n) => (
            <button
              key={n.id}
              className="search-result-item"
              onClick={() => onSelect(n.id)}
              type="button"
              aria-label={`${n.title}`}
            >
              <span className="result-icon">{n.icon || "📁"}</span>

              <div className="result-content">
                <div className="result-title">{n.title}</div>

                {n.description && (
                  <div className="result-description">{n.description}</div>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  },
);

export default SearchOverlay;
