/**
 * ---------------------------------------------------------------
 * DashboardTopBar – Oberleiste des Dashboards
 *
 * Aufgaben:
 * • Kategorien-Tabs (nur Nodes mit kind === "category")
 * • Filter (category | function)
 * • Suchfeld mit Debounce (Logik extern)
 * • i18n-Unterstützung
 * • Barrierefreiheit (ARIA-Rollen)
 * ---------------------------------------------------------------
 */

import React, { memo } from "react";
import { useTranslation } from "react-i18next";
import { NodeDetail } from "./types";

export interface DashboardTopBarProps {
  roots: NodeDetail[];
  selectedId: string;
  onSelectCategory: (id: string) => void;
  searchFilter: "category" | "function";
  setSearchFilter: React.Dispatch<
    React.SetStateAction<"category" | "function">
  >;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  searchLoading: boolean;
  searchQuery: string;
}

export const DashboardTopBar: React.FC<DashboardTopBarProps> = memo(
  ({
    roots,
    selectedId,
    onSelectCategory,
    searchFilter,
    setSearchFilter,
    onSearchChange,
    searchLoading,
    searchQuery,
  }) => {
    const { t } = useTranslation();

    // Nur Kategorien anzeigen
    const categories = roots.filter((n) => n.kind === "category");

    return (
      <header className="dashboard-topbar" aria-label="Dashboard Optionen">
        {/* Kategorien */}
        <nav
          className="topbar-categories"
          role="tablist"
          aria-label={t("dashboard.categories")}
        >
          {categories.map((cat) => {
            const isActive = selectedId === cat.id;

            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-controls={`category-${cat.id}`}
                className={`topbar-category-btn ${isActive ? "active" : ""}`}
                onClick={() => onSelectCategory(cat.id)}
                title={cat.title}
              >
                <span className="cat-icon">{cat.icon || "📁"}</span>
                <span className="cat-title">{cat.title}</span>
              </button>
            );
          })}
        </nav>

        {/* Suche */}
        <div className="topbar-search">
          {/* Filter */}
          <label className="visually-hidden" htmlFor="search-filter">
            {t("dashboard.search.filter")}
          </label>
          <select
            id="search-filter"
            className="search-filter"
            value={searchFilter}
            onChange={(e) =>
              setSearchFilter(e.target.value as "category" | "function")
            }
          >
            <option value="category">
              {t("dashboard.search.filterCategory")}
            </option>
            <option value="function">
              {t("dashboard.search.filterFunction")}
            </option>
          </select>

          {/* Suchfeld */}
          <label className="visually-hidden" htmlFor="dashboard-search-input">
            {t("dashboard.search.input")}
          </label>
          <input
            id="dashboard-search-input"
            type="search"
            className="search-input"
            placeholder={t("dashboard.search.placeholder", {
              type:
                searchFilter === "category"
                  ? t("dashboard.search.filterCategory")
                  : t("dashboard.search.filterFunction"),
            })}
            value={searchQuery}
            onChange={onSearchChange}
            aria-label={t("dashboard.search.input")}
          />

          {/* Ladeanzeige */}
          {searchLoading && (
            <div
              className="search-spinner"
              role="status"
              aria-live="polite"
              aria-label={t("dashboard.search.loading")}
            >
              ⏳
            </div>
          )}
        </div>
      </header>
    );
  }
);

DashboardTopBar.displayName = "DashboardTopBar";

export default DashboardTopBar;
