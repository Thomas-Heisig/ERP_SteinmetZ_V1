/**
 * ---------------------------------------------------------------
 * ErrorScreen – UI-Element für Fehlermeldungen im Dashboard
 *
 * Props
 * -----
 *   error   – Fehlermeldung (string | Error | unknown)
 *   onRetry – erneuter Versuch der ursprünglichen Anfrage
 *
 * Merkmale:
 * • klare Typisierung
 * • i18n-fähig
 * • barrierefrei (role="alert", aria-live="assertive")
 * • stabil gegen ungewöhnliche Fehlerobjekte
 * • React.memo zur Minimierung unnötiger Renders
 * ---------------------------------------------------------------
 */

import React, { memo } from "react";
import { useTranslation } from "react-i18next";

export interface ErrorScreenProps {
  error: unknown;
  onRetry: () => void;
}

/**
 * Fehler formatieren
 */
const formatError = (err: unknown): string => {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;

  try {
    return JSON.stringify(err);
  } catch {
    return "Unbekannter Fehler";
  }
};

export const ErrorScreen: React.FC<ErrorScreenProps> = memo(
  ({ error, onRetry }) => {
    const { t } = useTranslation();
    const errorMessage = formatError(error);

    return (
      <section
        className="error-state"
        role="alert"
        aria-live="assertive"
        aria-atomic="true"
        aria-label={t("dashboard.error.title")}
      >
        <h3 className="error-title">{t("dashboard.error.title")}</h3>

        <pre className="error-message">{errorMessage}</pre>

        <button
          className="retry-btn"
          onClick={onRetry}
          type="button"
          aria-label={t("dashboard.error.retryButton")}
        >
          {t("dashboard.error.retryButton")}
        </button>
      </section>
    );
  }
);

ErrorScreen.displayName = "ErrorScreen";

export default ErrorScreen;
