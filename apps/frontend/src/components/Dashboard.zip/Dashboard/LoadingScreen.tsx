/**
 * ---------------------------------------------------------------
 * LoadingScreen – UI-Element für Lade-Zustände im Dashboard
 *
 * • Präsentationskomponente, keine Props
 * • i18n via react-i18next
 * • Barrierefrei (role="status", aria-live="polite")
 * • React.memo zur Minimierung von Neu-Renders
 * ---------------------------------------------------------------
 */

import React, { memo } from "react";
import { useTranslation } from "react-i18next";

const LoadingScreen: React.FC = memo(() => {
  const { t } = useTranslation();

  return (
    <section
      className="loading-state"
      role="status"
      aria-live="polite"
      aria-atomic="true"
      aria-label={t("dashboard.loading.message")}
    >
      {/* Spinner – gesteuert über CSS */}
      <div className="loading-spinner" aria-hidden="true" />

      {/* Beschreibungstext */}
      <p className="loading-message">
        {t("dashboard.loading.message")}
      </p>
    </section>
  );
});

LoadingScreen.displayName = "LoadingScreen";

export default LoadingScreen;
export { LoadingScreen };
