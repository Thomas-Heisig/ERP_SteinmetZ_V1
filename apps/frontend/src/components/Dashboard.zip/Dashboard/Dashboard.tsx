// src/components/Dashboard/Dashboard.tsx

import React, {
  useMemo,
  useCallback,
  useEffect,
  useState,
  useRef,
} from "react";
import { useTranslation } from "react-i18next";

import { useTheme } from "../../contexts/ThemeContext";
import { useHealth, type HealthStatus } from "../../hooks/useHealth";
import {
  useFunctionsCatalog,
  type NodeDetail,
  type NodeKind,
} from "../../hooks/useFunctionsCatalog";

import { LanguageProvider } from "../LanguageSwitch/LanguageProvider";
import { LanguageSwitcher } from "../LanguageSwitch/LanguageSwitcher";

import { DashboardHeader } from "./DashboardHeader";
import { DashboardTopBar } from "./DashboardTopBar";
import { CategoryGrid } from "./CategoryGrid";
import { NodeDetails } from "./NodeDetails";
import { LoadingScreen } from "./LoadingScreen";
import { ErrorScreen } from "./ErrorScreen";
import { SearchOverlay } from "./SearchOverlay";

import QuickChat from "../QuickChat";
import { clsx } from "clsx";
import { debounce } from "lodash-es";


// ---------------------------------------------------------------------------
// Status-Definitionen
// ---------------------------------------------------------------------------
const STATUS_INFO: Record<HealthStatus, { color: string; text: string }> = {
  healthy: { color: "#10b981", text: "dashboard.online" },
  unhealthy: { color: "#f59e0b", text: "dashboard.degraded" },
  error: { color: "#ef4444", text: "dashboard.error" },
  checking: { color: "#6b7280", text: "dashboard.checking" },
};

const useStatusInfo = (status: HealthStatus) => STATUS_INFO[status];


// ---------------------------------------------------------------------------
// Icon Mapping
// ---------------------------------------------------------------------------
const CATEGORY_ICONS: Record<string, string[]> = {
  "📊": ["dashboard", "analytics"],
  "💰": ["finanz", "finance"],
  "🏭": ["betrieb", "operations"],
  "📦": ["lager", "inventory"],
  "👥": ["kunden", "customer"],
  "⚙️": ["system"],
  "📈": ["report", "bericht"],
  "🔍": ["analyse", "analytics"],
  "🛠️": ["werkzeug", "tool"],
};

const getDefaultCategoryIcon = (category: NodeDetail): string => {
  if (category.icon) return category.icon;

  const title = category.title.toLowerCase();
  const meta = (category.meta ?? {}) as Record<string, unknown>;
  const area = (meta.area as string)?.toLowerCase?.() ?? "";

  for (const [icon, keywords] of Object.entries(CATEGORY_ICONS)) {
    if (keywords.some((kw) => title.includes(kw) || area.includes(kw))) {
      return icon;
    }
  }
  return "📁";
};


// ---------------------------------------------------------------------------
// Dashboard Component
export const Dashboard: React.FC = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const backendUrl = import.meta.env.VITE_BACKEND_URL ?? "";

  const health = useHealth(backendUrl);
  const health = useHealth(backendUrl);

  const catalogConfig = useMemo(() => ({ baseUrl: backendUrl }), [backendUrl]);

  const {
    roots,
    rootsLoading,
    rootsError,
    selectedId,
    selectNode,
    node,
    nodeLoading,
    nodeError,
    searchQuery,
    searchResults,
    search,
    searchLoading,
    reloadIndex,
  } = useFunctionsCatalog(catalogConfig);

  const [showChat, setShowChat] = useState(false);
  const [searchFilter, setSearchFilter] = useState<"category" | "function">(
    "category"
  );
  const [isSearchActive, setIsSearchActive] = useState(false);

  const handleSetSearchFilter = useCallback((filter: "category" | "function") => {
    setSearchFilter(filter);
  }, []);
  );
  const [isSearchActive, setIsSearchActive] = useState(false);

  const fabRef = useRef<HTMLButtonElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);


  // -------------------------------------------------------------------------
  // Navigation
  // -------------------------------------------------------------------------
  const handleSelectNode = useCallback(
    (id: string) => {
      selectNode(id);
      setIsSearchActive(false);
    },
    [selectNode]
  );

  const handleBackNavigation = useCallback(() => {
    if (navigationStack.length === 0) {
      selectNode("");
      return;
    }

    const previous = navigationStack[navigationStack.length - 1];
    setNavigationStack((stack) => stack.slice(0, -1));
    selectNode(previous.id);
  }, [navigationStack, selectNode]);

  const handleCategoryClick = useCallback(
    (cat: NodeDetail) => {
      if (node) {
        setNavigationStack((stack) => [...stack, node]);
      }
      selectNode(cat.id);
      setIsSearchActive(false);
    },
    [node, selectNode]
  );

  const handleRootNavigation = useCallback(() => {
    setNavigationStack([]);
    selectNode("");
    setIsSearchActive(false);
  }, [selectNode]);


  // -------------------------------------------------------------------------
  // Keyboard Shortcuts
  // -------------------------------------------------------------------------
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // ESC - Chat schließen oder Suche zurücksetzen
      if (e.key === "Escape") {
        if (showChat) {
          setShowChat(false);
        } else if (isSearchActive) {
          setIsSearchActive(false);
          search("");
        }
      }
      
      // Cmd/Ctrl + K - Suche fokussieren
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
      
      // Cmd/Ctrl + / - Chat öffnen
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault();
        setShowChat(true);
      }
    };
    
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [showChat, isSearchActive, search]);


  // -------------------------------------------------------------------------
  // Zeit-Update
  // -------------------------------------------------------------------------
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  const debouncedSearch = useMemo(() => {
    return debounce((q: string) => {
      const kinds: NodeKind[] =
        searchFilter === "function" ? (["function"] as NodeKind[]) : (["category"] as NodeKind[]);
      search(q, kinds);
      setIsSearchActive(q.length > 0);
    }, 300);
  }, [search, searchFilter]);
      const kinds: NodeKind[] =
        searchFilter === "function" ? ["function"] : ["category"];
      search(q, kinds);
      setIsSearchActive(q.length > 0);
    }, 300);
  }, [search, searchFilter]);

  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value;
      debouncedSearch(value);
    },
    [debouncedSearch]
  );

  const handleSearchFilterChange = useCallback((filter: "category" | "function") => {
    setSearchFilter(filter);
    // Sofortige Suche mit neuem Filter
    if (searchQuery) {
      const kinds: NodeKind[] = filter === "function" ? (["function"] as NodeKind[]) : (["category"] as NodeKind[]);
      search(searchQuery, kinds);
    }
  }, [searchQuery, search]);
    // Sofortige Suche mit neuem Filter
    if (searchQuery) {
      const kinds: NodeKind[] = filter === "function" ? ["function"] : ["category"];
      search(searchQuery, kinds);
    }
  }, [searchQuery, search]);


  // -------------------------------------------------------------------------
  // Auto-Close Search bei Navigation
  // -------------------------------------------------------------------------
  useEffect(() => {
    if (selectedId && isSearchActive) {
      setIsSearchActive(false);
      search("");
    }
  }, [selectedId, isSearchActive, search]);


  // -------------------------------------------------------------------------
  // Performance Optimierungen
  // -------------------------------------------------------------------------
  const statusInfo = useStatusInfo(health.status);

  const visibleRoots = useMemo(() => 
    roots.filter((r) => r.kind !== "group" && r.kind !== "section"),
    [roots]
  );

  const filteredSearchResults = useMemo(() =>
    searchResults.filter((r) => r.kind !== "section"),
    [searchResults]
  );
    if (rootsLoading) {
      return (
        <LoadingScreen 
          messageKey="dashboard.loading.categories"
        />
      );
    }
        <LoadingScreen 
          message="dashboard.loading.categories"
    if (rootsError) {
      return (
        <ErrorScreen 
          error={rootsError} 
          onRetry={reloadIndex}
        />
      );
    }
          title="dashboard.error.categories.title"
          message="dashboard.error.categories.message"
        />
      );
    }

    // Search Results Overlay hat Vorrang
    if (isSearchActive && filteredSearchResults.length > 0) {
      return null; // SearchOverlay wird separat gerendert
    }

        <NodeDetails
          node={node}
          loading={nodeLoading}
          error={nodeError}
          onBack={handleBackNavigation}
          navigationStack={navigationStack}
          onSelectNode={handleSelectNode}
          setNavigationStack={setNavigationStack}
        />
          setNavigationStack={setNavigationStack}
          onRootNavigation={handleRootNavigation}
        />
      );
    }

    // Kategorie-Grid anzeigen
    return (
      <div className="dashboard-main-content">
        <div className="content-header">
          <h2 className="content-title">
            {t("dashboard.categories.title")}
          </h2>
          <p className="content-subtitle">
            {t("dashboard.categories.subtitle", { count: visibleRoots.length })}
          </p>
        </div>
        
        <CategoryGrid
          roots={visibleRoots}
          onCategoryClick={handleCategoryClick}
          getDefaultIcon={getDefaultCategoryIcon}
        />
      </div>
    );
  };


  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------
  return (
    <LanguageProvider>
        {/* Header */}
        <DashboardHeader
          health={health}
          statusColor={statusInfo.color}
          statusTextKey={statusInfo.text}
          currentTime={currentTime}
          onToggleChat={() => setShowChat((v) => !v)}
          showHomeButton={navigationStack.length > 0 || selectedId !== ""}
        />
          showHomeButton={navigationStack.length > 0 || selectedId !== ""}
        />
        {/* Top Bar mit Suche */}
        <DashboardTopBar
          roots={visibleRoots}
          selectedId={selectedId ?? ""}
          onSelectCategory={handleSelectNode}
          searchFilter={searchFilter}
          setSearchFilter={handleSetSearchFilter}
          onSearchChange={handleSearchChange}
          onSearchClear={handleSearchClear}
          searchLoading={searchLoading}
          searchQuery={searchQuery}
          searchInputRef={searchInputRef}
          isSearchActive={isSearchActive}
        />
        />

        {/* Hauptinhalt */}
        <main className="content-area" id="main-content">
          {renderMainContent()}
        </main>

        {/* Search Overlay */}
        {isSearchActive && filteredSearchResults.length > 0 && (
          <SearchOverlay
            results={filteredSearchResults}
            onClose={handleSearchClear}
            onSelect={handleSelectNode}
            searchQuery={searchQuery}
            searchFilter={searchFilter}
          />
        )}

        {/* No Search Results */}
        {isSearchActive && searchQuery && filteredSearchResults.length === 0 && !searchLoading && (
          <div className="search-no-results">
            <div className="no-results-content">
              <div className="no-results-icon">🔍</div>
              <h3 className="no-results-title">
                {t("dashboard.search.noResults.title")}
              </h3>
              <p className="no-results-message">
                {t("dashboard.search.noResults.message", { query: searchQuery })}
              </p>
              <button 
                className="btn-secondary"
                onClick={handleSearchClear}
                type="button"
              >
                {t("dashboard.search.clear")}
              </button>
            </div>
          </div>
        )}

        {/* Floating Action Button */}
        <button
          ref={fabRef}
          className={clsx("fab", { "fab-hidden": showChat })}
          onClick={() => setShowChat(true)}
          aria-label={t("dashboard.openChat")}
          type="button"
          title={t("dashboard.openChat")}
        >
          <span className="fab-icon">💬</span>
          <span className="fab-pulse"></span>
        </button>
        {/* Quick Chat */}
        <QuickChat 
          isOpen={showChat} 
          onClose={() => setShowChat(false)}
        />
        />

        {/* Language Switcher */}
        <div className="language-switcher-wrapper">
          <LanguageSwitcher />
        </div>

        {/* Keyboard Shortcuts Hint */}
        <div className="keyboard-shortcuts-hint">
          <kbd>Ctrl</kbd> + <kbd>K</kbd> {t("dashboard.search.shortcut")}
        </div>
      </div>
    </LanguageProvider>
  );
};

// Performance Optimierung
Dashboard.displayName = "Dashboard";

export default Dashboard;